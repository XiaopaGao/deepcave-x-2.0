import base64
import unittest

from dashboard_config.generic import importance
from dashboard_config.stagnation import find_stagnation_segments, make_diagnosis
from log_import import import_file


class CoreTests(unittest.TestCase):
    def test_stagnation_and_diagnosis(self):
        segments = find_stagnation_segments([.8, .9, .9, .9, .9, .9, .91], patience=3, min_delta=.001)
        self.assertEqual(segments, [(3, 6)])
        self.assertIn("停滞", make_diagnosis(segments, 7))

    def test_importance(self):
        rows = [(i, i / 20, {"useful": i, "constant": 1}) for i in range(12)]
        result = importance(rows)
        self.assertGreater(result["useful"], result["constant"])

    def test_optuna_csv_import(self):
        csv = "number,value,state,params_x\n0,0.8,COMPLETE,1\n1,0.9,COMPLETE,2\n"
        content = "data:text/csv;base64," + base64.b64encode(csv.encode()).decode()
        run = import_file(content, "study.csv", "upper")
        self.assertEqual(len(list(run.get_trials())), 2)
        self.assertEqual(run.meta["framework"], "Optuna CSV")


if __name__ == "__main__":
    unittest.main()
