"""复现三个数据集上的 Optuna/SMAC 对比，并导出网页可上传日志。"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import zipfile
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import optuna
import pandas as pd
from ConfigSpace import ConfigurationSpace, Integer
from sklearn.datasets import fetch_covtype, fetch_openml, load_digits
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from smac import HyperparameterOptimizationFacade, Scenario

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from dashboard_config.generic import importance  # noqa: E402
from dashboard_config.stagnation import find_stagnation_segments, make_diagnosis  # noqa: E402

PARAMS = ("n_estimators", "max_depth", "min_samples_split", "min_samples_leaf")
RANGES = {
    "digits": ((20, 120), (2, 20), (2, 20), (1, 10)),
    "letter": ((30, 100), (5, 30), (2, 20), (1, 10)),
    "covtype": ((30, 100), (5, 30), (2, 20), (1, 10)),
}
DEFAULT_TRIALS = {"digits": 30, "letter": 20, "covtype": 20}


def load_dataset(name: str, sample_size: int):
    cache = ROOT / "data_cache"
    if name == "digits":
        data = load_digits()
        return data.data, data.target
    if name == "letter":
        data = fetch_openml(data_id=6, as_frame=False, parser="auto", data_home=cache)
        return data.data.astype(np.float32), data.target.astype(str)
    data = fetch_covtype(data_home=cache, as_frame=False)
    x, y = data.data.astype(np.float32), data.target.astype(np.int16)
    if sample_size and sample_size < len(x):
        x, _, y, _ = train_test_split(x, y, train_size=sample_size, random_state=42, stratify=y)
    return x, y


def make_space(name: str) -> ConfigurationSpace:
    space = ConfigurationSpace(seed=42)
    space.add([Integer(param, bounds=bounds) for param, bounds in zip(PARAMS, RANGES[name])])
    return space


def parameters(config) -> dict[str, int]:
    return {name: int(config[name]) for name in PARAMS}


def package_smac(run_root: Path, target: Path) -> None:
    found = {}
    for filename in ("configspace.json", "scenario.json", "runhistory.json"):
        matches = list(run_root.rglob(filename))
        if len(matches) != 1:
            raise RuntimeError(f"SMAC 输出中 {filename} 的数量应为 1，实际为 {len(matches)}")
        found[filename] = matches[0]
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for filename, path in found.items():
            archive.write(path, filename)


def save_analysis(name: str, optuna_df: pd.DataFrame, smac_df: pd.DataFrame, out: Path) -> None:
    summary = []
    for method, frame in (("Optuna-TPE", optuna_df), ("SMAC", smac_df)):
        analysis_rows = [
            (i + 1, float(row.value), {p: getattr(row, f"params_{p}") for p in PARAMS})
            for i, row in enumerate(frame.itertuples())
        ]
        scores = importance(analysis_rows)
        pd.DataFrame(scores.items(), columns=["hyperparameter", "importance"]).to_csv(
            out / f"{method.lower()}_importance.csv", index=False)
        segments = find_stagnation_segments(frame["value"].tolist(), patience=5, min_delta=.001)
        summary.append({"dataset": name, "method": method, "trials": len(frame),
                        "best_cv_accuracy": frame["value"].max(),
                        "stagnation_segments": str(segments),
                        "diagnosis": make_diagnosis(segments, len(frame))})
    pd.DataFrame(summary).to_csv(out / "analysis_summary.csv", index=False)
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(optuna_df["number"] + 1, optuna_df["value"].cummax(), marker="o", label="Optuna / TPE")
    ax.plot(smac_df["number"] + 1, smac_df["value"].cummax(), marker="s", linestyle="--", label="SMAC")
    ax.set(xlabel="Trial", ylabel="Best cross-validation accuracy", title=f"{name}: optimizer trajectory")
    ax.grid(alpha=.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out / "trajectory_comparison.png", dpi=160)
    plt.close(fig)


def run(name: str, trials: int, sample_size: int) -> None:
    out = ROOT / "examples" / name
    raw = out / "smac_raw"
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    x, y = load_dataset(name, sample_size)
    x_train, x_test, y_train, y_test = train_test_split(
        x, y, test_size=.2, random_state=42, stratify=y)
    cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)

    def evaluate(values) -> float:
        model = RandomForestClassifier(**parameters(values), random_state=42, n_jobs=-1)
        return float(cross_val_score(model, x_train, y_train, cv=cv, scoring="accuracy", n_jobs=1).mean())

    def optuna_objective(trial) -> float:
        values = {p: trial.suggest_int(p, *bounds) for p, bounds in zip(PARAMS, RANGES[name])}
        return evaluate(values)

    optuna.logging.set_verbosity(optuna.logging.WARNING)
    study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=42))
    study.optimize(optuna_objective, n_trials=trials)
    optuna_df = study.trials_dataframe()
    optuna_df.to_csv(out / "optuna.csv", index=False)

    smac_rows = []
    def smac_objective(config, seed=42):
        score = evaluate(config)
        smac_rows.append({"number": len(smac_rows), "value": score,
                          **{f"params_{p}": int(config[p]) for p in PARAMS}})
        return 1.0 - score

    scenario = Scenario(make_space(name), deterministic=True, n_trials=trials, seed=42, output_directory=raw)
    optimizer = HyperparameterOptimizationFacade(scenario, smac_objective, overwrite=True)
    incumbent = optimizer.optimize()
    smac_df = pd.DataFrame(smac_rows)
    smac_df.to_csv(out / "smac_trials.csv", index=False)
    package_smac(raw, out / "smac.zip")
    shutil.rmtree(raw)

    test_rows = []
    for method, best in (("Optuna-TPE", study.best_params), ("SMAC", parameters(incumbent))):
        model = RandomForestClassifier(**best, random_state=42, n_jobs=-1).fit(x_train, y_train)
        test_rows.append({"dataset": name, "method": method,
                          "best_cv_accuracy": study.best_value if method == "Optuna-TPE" else smac_df.value.max(),
                          "test_accuracy": accuracy_score(y_test, model.predict(x_test)),
                          "best_params": json.dumps(best)})
    pd.DataFrame(test_rows).to_csv(out / "final_test_results.csv", index=False)
    save_analysis(name, optuna_df, smac_df, out)
    print(f"完成 {name}: {out}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", choices=["digits", "letter", "covtype", "all"], default="all")
    parser.add_argument("--trials", type=int, help="覆盖每种优化器的试验次数")
    parser.add_argument("--covtype-sample-size", type=int, default=100_000)
    args = parser.parse_args()
    names = list(RANGES) if args.dataset == "all" else [args.dataset]
    for name in names:
        run(name, args.trials or DEFAULT_TRIALS[name], args.covtype_sample_size)


if __name__ == "__main__":
    main()
