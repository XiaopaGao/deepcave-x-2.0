# DeepCAVE-X

这是一个用于分析 AutoML 超参数优化过程的网页工具。它可以导入 Optuna 和 SMAC 的实验日志，比较两种优化器的搜索轨迹，分析哪些参数更重要，并识别搜索过程中的停滞区间。

## 接手后先做什么

如果你收到的是 ZIP 压缩包，请按下面顺序操作。通常不需要修改代码。

1. 解压 ZIP，打开其中的 `DeepCAVE-X` 文件夹。
2. 确认文件夹第一层能看到 `app.py`、`requirements.txt`、`render.yaml` 和本 `README.md`。
3. 把整个 `DeepCAVE-X` 文件夹的内容上传到 GitHub 仓库根目录。
4. GitHub 上传完成后，按照 [docs/部署到Render步骤.md](docs/部署到Render步骤.md) 创建 Render 服务。
5. 部署成功后，用 `examples/` 中的示例日志检查网页功能。

如果只负责提交，不需要理解 Python，也不需要打开三个 Notebook。遇到部署问题时，把 Render 页面中的 Deploy Logs 完整复制给项目作者即可。

## 文件结构

```text
DeepCAVE-X/
├─ README.md                 ← 当前说明；接手后首先阅读
├─ app.py                    ← 网页主程序，也是本地运行入口
├─ log_import.py             ← 读取和检查 Optuna、SMAC 日志
├─ requirements.txt          ← 运行项目所需的 Python 软件清单
├─ render.yaml               ← Render 自动部署配置
├─ .python-version           ← 指定使用 Python 3.10
├─ assets/                   ← 网页样式和 Optuna JSON 导出工具
├─ dashboard_config/         ← 参数重要性和停滞诊断算法
├─ examples/                 ← 三个数据集的完整示例结果及上传文件
├─ experiments/              ← 一键重现实验的 Python 脚本
├─ notebooks/                ← 三个数据集的实验过程和运行记录
├─ tests/                    ← 自动检查核心功能是否正常
└─ docs/                     ← 使用、部署和第三方依赖说明
```

## 每个文件夹有什么用

### `assets/`

- `style.css`：网页的颜色、字体、布局和动画。
- `export_optuna.py`：把 Optuna Study 导出成网页支持的 JSON 文件。

### `dashboard_config/`

- `generic.py`：读取实验轨迹并计算随机森林 MDI 参数重要性。
- `stagnation.py`：检测停滞区间并生成诊断文字。

### `examples/`

包含 `digits`、`letter` 和 `covtype` 三套结果。每套目录中：

- `optuna.csv`：可直接上传到网页的 Optuna 日志。
- `smac.zip`：可直接上传到网页的 SMAC 日志。
- `trajectory_comparison.png`：两种优化器的轨迹对比图。
- `analysis_summary.csv`：最佳成绩和停滞诊断。
- `*_importance.csv`：参数重要性结果。
- `final_test_results.csv`：最佳配置在测试集上的结果。

这些示例文件需要保留并上传到 GitHub，它们用于证明和检查项目功能。

### `experiments/`

- `run_benchmarks.py`：重新运行三个数据集实验并生成 `examples/`。一般提交和部署时不需要重新运行。

### `notebooks/`

- `04_digits_optuna_vs_smac.ipynb`：Digits 手写数字实验。
- `05_letter_openml_optuna_vs_smac.ipynb`：OpenML Letter 实验。
- `06_covtype_optuna_vs_smac.ipynb`：Forest CoverTypes 实验。

Notebook 已保留运行过程和输出，查看实验细节时再打开。

### `tests/`

- `test_core.py`：检查日志导入、参数重要性和停滞诊断是否正常。

### `docs/`

- `部署到Render步骤.md`：给负责上线的人看的逐步部署说明。
- `使用说明.md`：网页上传日志和比较实验的说明。
- `第三方说明.md`：使用到的开源项目和引用信息。

## 上传 GitHub 时的检查清单

应该上传：

- 根目录中的全部文件；
- `assets`、`dashboard_config`、`examples`、`experiments`、`notebooks`、`tests`、`docs` 文件夹。

不应该上传：

- `.git`、`.idea`、`.venv`；
- `data_cache`、`.pip-cache`、`__pycache__`；
- 其他原始数据集、密码、令牌或个人文件。

GitHub 仓库首页必须直接看到 `app.py`，不能变成 `deepcave-x/DeepCAVE-X/app.py` 这种多套一层的结构。

## 部署成功后怎样检查

1. 打开 Render 提供的网址，确认首页正常显示。
2. 在任务标识中填写 `digits_demo`。
3. 上传 `examples/digits/optuna.csv`，并选择“准确率、AUC”。
4. 再上传 `examples/digits/smac.zip`。
5. 在运行 A、运行 B 中分别选择两份日志。
6. 勾选实验条件可比较，查看轨迹对比。
7. 打开“超参数重要性”和“瓶颈诊断”，确认图表能显示。

## 本地运行（可选）

如果接手人只负责上传和部署，可以跳过这一节。开发者在 Windows PowerShell 中可执行：

```powershell
cd D:\deepcave-x
conda create -p .venv -c conda-forge python=3.10 pip pyrfr swig
conda run -p .venv pip install -r requirements.txt
conda run -p .venv python app.py
```

浏览器打开 <http://127.0.0.1:8051/>。

运行自动检查：

```powershell
conda run -p .venv python -m unittest discover -s tests -v
```

## 日志格式和限制

- Optuna CSV：`study.trials_dataframe().to_csv("optuna.csv", index=False)`
- Optuna JSON：使用 `assets/export_optuna.py`
- SMAC 2.x ZIP：包含 `configspace.json`、`scenario.json` 和 `runhistory.json`

网页不接受 pickle、训练模型或原始数据集。单文件上限为 8 MB，单份日志最多包含 5000 条试验。
